<?php
header('Content-Type: text/html; charset=utf-8');

if(isset($_POST['email'])) {
 
     
    // EDIT THE 2 LINES BELOW AS REQUIRED
 
    $email_to = "gestion@recell.cl";
 
    $email_subject = "Solicitud Recell";
 
   
    $first_name = $_POST['nombre']; // required 
    $email_from = $_POST['email']; // required
	$phone = $_POST['telefono']; // required
	$isapre = $_POST['isapre']; // required
	
    $comments = $_POST['mensaje']; // required
 
    $email_message = "Detalles del contacto.\n\n";
    $email = "gestion@recell.cl"; // required
 
    
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
 
 
    $email_message .= "Nombre: ".clean_string($first_name)."\n";
    $email_message .= "Correo: ".clean_string($email_from)."\n";
	$email_message .= "Telefono: ".clean_string($phone)."\n";
	$email_message .= "Tipo de cancer: ".clean_string($isapre)."\n";
    $email_message .= "Mensaje: ".clean_string($comments)."\n";
 
     
// create email headers

$headers = 'From: '.$email."\r\n".
 
'Reply-To: '.$email_from."\r\n" .
 
'X-Mailer: PHP/' . phpversion();
 
@mail($email_to, $email_subject, $email_message, $headers); 
 
?>
 
<!-- include your own success html here -->
 
<head>
	
	
	

	
	

<!-- Global site tag (gtag.js) - Google Ads: 806113768 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-806113768"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-806113768');
</script>

<!-- Event snippet for ISAPRE conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-806113768/LBrHCN-4-acBEOijsYAD'});
</script>




</head>
 

<body background="assets/images/fondo.jpg">					
						<h1 style="text-align:center; float:inherit; color:#0077c8; margin-top: 300px; font-family:'Helvetica Neue', Helvetica, Arial, sans-serif" >¡Hemos recibido satisfactoriamente tu solicitud!
							<br><br>
	
					Un asesor se contactará a la brevedad.</h1>
						




						
						</body>
                            

  
<?php
 
}

?>